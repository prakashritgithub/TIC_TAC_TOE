package ram;

//import ram.Humanplayer;

public class toe {

	public static void main(String[] args) {
		tictactoe t = new tictactoe();
		Humanplayer  p1 = new Humanplayer("Prav",'x');
		 AIplayer p2 =new AIplayer("toi",'O');
		
		player cp;
		cp=p1;
		while(true) 
		{
			System.out.println(cp.Name + " TURN");
			cp.makemove();
			tictactoe.displayboard();
			if(tictactoe.checkingcol() || tictactoe.checkingrow()||tictactoe.checkdiag()) 
			{
				System.out.println(cp.Name +" IS WON");
				break;
			}
			else if(tictactoe.checkdraw()) {
				System.out.println("GAME IS DRAW");
			}
			else
			{
				if(cp==p1) {
					cp=p2;
				}
				else {
					cp=p1;
				}
			}
		}
		
       
       
        
        }

}
